class car:
    def__init__(self):
        self.cgst=5555
        self.sgst=5555
        self.insurance=5555
def company(self):
    while true:
        print("toyota,mercendes")
        self.n=input("enter the car company")
        if self.n=="toyota":
            print("welcome to toyota")
            self.mode1()
            break
        else self.n=="mercendes":
            print("welcome to merc")
            self.model()
            break
        else:
            print("Enter valid company")
def model(self):
    if self.n=="toyota":
        while true:
            print("select from fortuner and ic ")
            self.choice=input("enter the car")
            if self.choice=="fortuner"
            self.price(self.choice)
            break
        elif self.n =="LC":
            self.price(self.choice)
            break
        else:
            print("enter value")
        elif self.n=="Mercendes":
            while True:
                print("select from amg and gw")
                self.choice == "amg":
                    self.price(self.choice)
                    break
                else:
                    print("enter value")
def price(self,choice):
    if choice=="fortuner":
        self.p=4500000
        elif choices== "Ic":
            self.p=1050000
            elif choice=="amg":
                self.p=25000000
                elif.choice=="gu":
                    self.p=300000000
                    for_p=self.p+self.sgst+self.cgst+self.insurance
                    print(tot_p)
                    
                    
c = car
c.company()
                    
                
            
        
        
        
        
        
        
        
        
        
        
        
        
        