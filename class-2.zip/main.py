class shopping(F15):
  def __init__(self,place):
      self.place = place
      print("welcome to shopping at",place)
  def dresstype(self,type):
      self.t = type
  def d_price(self,price):
      self.p = price
  def d_size(self,size):
      self,s = size
  def display(self):