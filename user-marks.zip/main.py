m1=int(input("enter the marks")
p1=int(input("enter the marks")
c1=int(input("enter the marks")

if m1>80 and p1>80 and c1>80
print("A+")
elif m1>60 and p1>60 and c1>60
print("B+")
elif m1>80 and p1>80 and c1>80
print("pass")
