class F15:
    def light(self):
        print("ok switching on the lights")
    def fan(self,speed):
        print("fan is on and the speed is",speed)
        self.s = speed
    def cpu(self):
        print("powering on the system")
        print(self.s)
chandu = F15()
chandu.light()
chandu.fan(5)
chandu.cpu()